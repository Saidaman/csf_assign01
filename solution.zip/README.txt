# csf_assign01
Shayan Hossain (JHED: shossa11) & Saidaman Earla (JHED: searla1)

Please note:
Most of the work was done together, with very little emphasis on individual work. But for the purpose
of this README, below are *estimations* of who mostly worked on what functionality. Whatever 
funcionality/functions are not mentioned below were evenly split among the team members (the short functions
like the the two create functions, the is_ functions, compare, negate, etc.).

Saidaman Earla Contributions:
Prepared GitHub repo, mostly worked on fixedpoint arithmetic functions like add, subtract, halve, double.

Shayan Hossain Contributions:
Mostly worked on hex functions like create_from_hex, format_as_hex, and did finishing touches (stylistic consistency, etc.).
